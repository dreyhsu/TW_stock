from django.db import models


# Create your models here.
class Uptrend(models.Model):
    Date = models.DateTimeField()
    stock_id = models.CharField(max_length=10)

