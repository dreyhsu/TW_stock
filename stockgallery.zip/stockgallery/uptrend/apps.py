from django.apps import AppConfig


class UptrendConfig(AppConfig):
    name = 'uptrend'
